import numpy as np
import sys

# why?
sys.path.append("atu/optimized_dp")

from Grid.GridProcessing import Grid

# x y th v phi
grid_low = np.array(
    [-8, -3.8, 0.1, -1.1 * np.pi]
)  # mul by 1.1 to allow mod to go to -pi
grid_high = np.array([8, 3.8, 6.5, 1.1 * np.pi])

# for v, deepreach normalizes with (v - beta) / alpha to be in range [-1, 1]
# (7 -  3) / 4 -> 1 (-1 -3) / 4 -> -1

# grid_pts = np.array([40, 40, 40, 40, 40])
grid_pts = np.array([30, 30, 20, 20])
grid = Grid(
    grid_low,
    grid_high,
    4,
    grid_pts,
    [3],
)

L = 2.0
CURB_POSITION = np.array([-2.8, 2.8])
STRANDED_CAR_POS = np.array([0.0, -1.8])
STRANDED_R2_POS = np.array([-6.0, 1.8])

GOAL_POS = np.array([6.0, -1.4])

if __name__ in "__main__":
    from Shapes.ShapesFunctions import *
    from dynamics.SingleNarrowPassage import SingleNarrowPassage
    from dynamics.Siren import SirenSingleNarrowPassage
    from dynamics.DubinsCar4D2 import DubinsCar4D2
    from dynamics.DubinsCar import DubinsCar
    from plot_options import *

    from solver import HJSolver

    def dubincar():
        grid_low = np.array(
            [-8, -3.8,-1.1 * np.pi]
        )  # mul by 1.1 to allow mod to go to -pi
        grid_high = np.array([8, 3.8, 1.1 * np.pi])

        # for v, deepreach normalizes with (v - beta) / alpha to be in range [-1, 1]
        # (7 -  3) / 4 -> 1 (-1 -3) / 4 -> -1

        # grid_pts = np.array([40, 40, 40, 40, 40])
        grid_pts = np.array([30, 30, 20])
        grid = Grid(
            grid_low,
            grid_high,
            3,
            grid_pts,
            [2],
        )
        # car = SingleNarrowPassage(u_mode="min", d_mode="max") # ra
        # car = SirenSingleNarrowPassage(u_mode="min", d_mode="max") # ra
        car = DubinsCar(uMode="min", dMode="max") # ra
        # car = SingleNarrowPassage(u_mode="max", d_mode="min") # brt

        # using env_setting =='v2'

        goal = CylinderShape(grid, np.array([2, 3, 4]), center=GOAL_POS, radius=L)

        curb = Union(
            Lower_Half_Space(grid, 1, CURB_POSITION[0] + 0.5 * L),
            Upper_Half_Space(grid, 1, CURB_POSITION[1] - 0.5 * L),
        )

        stranded_car = CylinderShape(
            grid, np.array([2, 3, 4]), center=STRANDED_CAR_POS, radius=L
        )
        stranded_r2_pos = CylinderShape(
            grid, np.array([2, 3, 4]), center=STRANDED_R2_POS, radius=L
        )

        obstacle = Union(curb, Union(stranded_r2_pos, stranded_car))
        # obstacle = Union(curb, stranded_car)

        tau = np.arange(start=0, stop = 20 + 0.05, step=0.05)
        # tau = np.arange(start=0, stop=1 + 0.05, step=0.05)

        po = PlotOptions(
            do_plot=True, plot_type="3d_plot", plotDims=[0, 1, 2], slicesCut=[]
        )

        comp_method = { "TargetSetMode": "minVWithVTarget", "ObstacleSetMode": "maxVWithObstacle"}
        result = HJSolver(car, grid, [goal, obstacle], tau, comp_method, po, saveAllTimeSteps=False)
        # # np.save("./atu/envs/assets/brts/single_narrow_passage_ra.npy", result)
        # compMethods = {"TargetSetMode": "minVWithV0"}
        # result = HJSolver(car, grid, obstacle, tau, compMethods, po, saveAllTimeSteps=False)
        # result = HJSolver(car, grid, goal, tau, compMethods, po, saveAllTimeSteps=False)



    def dubincar4d():
        # x y th v phi
        grid_low = np.array(
            [-8, -3.8, 0.1, -1.1 * np.pi]
        )  # mul by 1.1 to allow mod to go to -pi
        grid_high = np.array([8, 3.8, 6.5, 1.1 * np.pi])

        # for v, deepreach normalizes with (v - beta) / alpha to be in range [-1, 1]
        # (7 -  3) / 4 -> 1 (-1 -3) / 4 -> -1

        # grid_pts = np.array([40, 40, 40, 40, 40])
        grid_pts = np.array([30, 30, 20, 20])
        grid = Grid(
            grid_low,
            grid_high,
            4,
            grid_pts,
            [3],
        )
        # car = SingleNarrowPassage(u_mode="min", d_mode="max") # ra
        # car = SirenSingleNarrowPassage(u_mode="min", d_mode="max") # ra
        car = DubinsCar4D2(uMode="min", dMode="max") # ra
        # car = SingleNarrowPassage(u_mode="max", d_mode="min") # brt

        # using env_setting =='v2'

        goal = CylinderShape(grid, np.array([2, 3, 4]), center=GOAL_POS, radius=L)

        curb = Union(
            Lower_Half_Space(grid, 1, CURB_POSITION[0] + 0.5 * L),
            Upper_Half_Space(grid, 1, CURB_POSITION[1] - 0.5 * L),
        )

        stranded_car = CylinderShape(
            grid, np.array([2, 3, 4]), center=STRANDED_CAR_POS, radius=L
        )
        stranded_r2_pos = CylinderShape(
            grid, np.array([2, 3, 4]), center=STRANDED_R2_POS, radius=L
        )

        obstacle = Union(curb, Union(stranded_r2_pos, stranded_car))
        # obstacle = Union(curb, stranded_car)

        tau = np.arange(start=0, stop = 20 + 0.05, step=0.05)
        # tau = np.arange(start=0, stop=1 + 0.05, step=0.05)

        po = PlotOptions(
            do_plot=True, plot_type="3d_plot", plotDims=[0, 1, 3], slicesCut=[0]
        )

        comp_method = { "TargetSetMode": "minVWithVTarget", "ObstacleSetMode": "maxVWithObstacle"}
        result = HJSolver(car, grid, [goal, obstacle], tau, comp_method, po, saveAllTimeSteps=False)
        # # np.save("./atu/envs/assets/brts/single_narrow_passage_ra.npy", result)
        # compMethods = {"TargetSetMode": "minVWithV0"}
        # result = HJSolver(car, grid, obstacle, tau, compMethods, po, saveAllTimeSteps=False)
        # result = HJSolver(car, grid, goal, tau, compMethods, po, saveAllTimeSteps=False)

    # dubincar4d()

    def siren():
        # x y th v phi
        grid_low = np.array(
            [-8, -3.8, -1.1 * np.pi, 0.1,  -1.2 * 0.3 * np.pi]
        )  # mul by 1.1 to allow mod to go to -pi
        grid_high = np.array([8, 3.8, 1.1 * np.pi, 6.5, 1.2 * 0.3 * np.pi])

        # for v, deepreach normalizes with (v - beta) / alpha to be in range [-1, 1]
        # (7 -  3) / 4 -> 1 (-1 -3) / 4 -> -1

        # grid_pts = np.array([40, 40, 40, 40, 40])
        grid_pts = np.array([30, 30, 20, 20, 20])
        grid = Grid(
            grid_low,
            grid_high,
            5,
            grid_pts,
            [2, 4],
        )
        # car = SingleNarrowPassage(u_mode="min", d_mode="max") # ra
        # car = SirenSingleNarrowPassage(u_mode="min", d_mode="max", length=L, psi_max=np.pi/18, psi_min=-np.pi/18, alpha_max=1.5, alpha_min=-1.5) # ra
        # car = SirenSingleNarrowPassage(u_mode="min", d_mode="max") # ra
        # car = DubinsCar4D2(uMode="min", dMode="max") # ra
        car = SingleNarrowPassage(u_mode="max", d_mode="min") # brt

        # using env_setting =='v2'

        goal = CylinderShape(grid, np.array([2, 3, 4]), center=GOAL_POS, radius=L)

        curb = Union(
            Lower_Half_Space(grid, 1, CURB_POSITION[0] + 0.5 * L),
            Upper_Half_Space(grid, 1, CURB_POSITION[1] - 0.5 * L),
        )

        stranded_car = CylinderShape(
            grid, np.array([2, 3, 4]), center=STRANDED_CAR_POS, radius=L
        )
        stranded_r2_pos = CylinderShape(
            grid, np.array([2, 3, 4]), center=STRANDED_R2_POS, radius=L
        )

        obstacle = Union(curb, Union(stranded_r2_pos, stranded_car))
        # obstacle = Union(curb, stranded_car)

        # tau = np.arange(start=0, stop = 10 + 0.05, step=0.05)
        tau = np.arange(start=0, stop=1 + 0.05, step=0.05)

        po = PlotOptions(
            do_plot=True, plot_type="3d_plot", plotDims=[0, 1, 2], slicesCut=[10, 10]
        )

        # comp_method = { "TargetSetMode": "minVWithVTarget", "ObstacleSetMode": "maxVWithObstacle"}
        # result = HJSolver(car, grid, [goal, obstacle], tau, comp_method, po, saveAllTimeSteps=False)
        compMethods = {"TargetSetMode": "minVWithV0"}
        result = HJSolver(car, grid, obstacle, tau, compMethods, po, saveAllTimeSteps=False)
        # result = HJSolver(car, grid, goal, tau, compMethods, po, saveAllTimeSteps=False)
        np.save("./atu/envs/assets/brts/single_narrow_passage_brt_siren.npy", result)

    siren()

import numpy as np

import sys


sys.path.append("atu/optimized_dp")

# Utility functions to initialize the problem
from Grid.GridProcessing import Grid

g = Grid(
    np.array([-4.5, -4.5, -np.pi]),
    np.array([4.5, 4.5, np.pi]),
    3,
    np.array([80, 80, 40]),
    [2],
)

# car_r = 0.35
car_r = 0.5


if __name__ in "__main__":
    from Shapes.ShapesFunctions import *

    from dynamics.DubinsCar import *

    # Plot options
    from plot_options import *

    # Solver core
    from solver import HJSolver

    import math

    """ USER INTERFACES
    - Define grid
    - Generate initial values for grid using shape functions
    - Time length for computations
    - Initialize plotting option
    - Call HJSolver function
    """

    Initial_value_f = Shape(g,)

    def brt(dist=True):
        lookback_length = 2.5
        t_step = 0.05
        small_number = 1e-5
        tau = np.arange(start=0, stop=lookback_length + small_number, step=t_step)

        # avoid
        my_car = DubinsCar(uMode="max", dMode="min")

        if dist:
            my_car = DubinsCar(uMode="max", dMode="min", dMax=[0.1, 0.1, 0.1])

        compMethods = {"TargetSetMode": "minVWithVInit"}

        result = HJSolver(
            my_car,
            g,
            Initial_value_f,
            tau,
            compMethods,
            PlotOptions(
                do_plot=False, plot_type="3d_plot", plotDims=[0, 1, 2], slicesCut=[]
            ),
            saveAllTimeSteps=False,
        )
        np.save("min_brt_dist.npy", result)

        # lookback_length = 0.35
        # t_step = 0.05

        # small_number = 1e-5
        # tau2 = np.arange(start=0, stop=lookback_length + small_number, step=t_step)

        # # reach
        # my_car = DubinsCar(uMode="min", dMode="max", dMax=[0.1, 0.1, 0.1])
        # compMethods = {"TargetSetMode": "minVWithVInit"}
        # result = HJSolver(
        #     my_car,
        #     g,
        #     result,
        #     tau2,
        #     compMethods,
        #     PlotOptions(
        #         do_plot=False, plot_type="3d_plot", plotDims=[0, 1, 2], slicesCut=[]
        #     ),
        #     saveAllTimeSteps=False,
        # )

        # if dist:
        #     np.save("max_over_min_brt_dist_035.npy", result)
        # else:
        #     np.save("max_over_min_brt.npy", result)

    def brt_test(dist=False):
        lookback_length = 2.5
        t_step = 0.05
        small_number = 1e-5
        tau = np.arange(start=0, stop=lookback_length + small_number, step=t_step)

        # avoid
        my_car = DubinsCar4(uMode="max", dMode="min")

        if dist:
            my_car = DubinsCar4(uMode="max", dMode="min", dMax=[0.1, 0.1, 0.1, 0])

        compMethods = {"TargetSetMode": "minVWithVInit"}

        result = HJSolver(
            # my_car,
            DubinsCar4D(),
            g4,
            Initial_value_f,
            tau,
            compMethods,
            PlotOptions(
                do_plot=True, plot_type="3d_plot", plotDims=[0, 1, 2], slicesCut=[]
            ),
            saveAllTimeSteps=False,
        )

        # lookback_length = 0.1
        # t_step = 0.05

        # small_number = 1e-5
        # tau2 = np.arange(start=0, stop=lookback_length + small_number, step=t_step)

        # # reach
        # my_car = DubinsCar(uMode="min", dMode="max")
        # compMethods = {"TargetSetMode": "minVWithVInit"}
        # result = HJSolver(
        #     my_car,
        #     g,
        #     result,
        #     tau2,
        #     compMethods,
        #     PlotOptions(
        #         do_plot=True, plot_type="3d_plot", plotDims=[0, 1, 2], slicesCut=[]
        #     ),
        #     saveAllTimeSteps=False,
        # )

        # if dist:
        #     np.save("max_over_min_brt_dist.npy", result)
        # else:
        #     np.save("max_over_min_brt.npy", result)

    def ra():
        goal = CylinderShape(g, [2], np.array([-2, 2.3]), 0.5)
        obstacle = Initial_value_f
        my_car = DubinsCar(uMode="min", dMode="max")

        compMethods = {
            "TargetSetMode": "minVWithVTarget",
            "ObstacleSetMode": "maxVWithObstacle",
        }

        lookback_length = 20.0
        t_step = 0.05

        small_number = 1e-5
        tau = np.arange(start=0, stop=lookback_length + small_number, step=t_step)
        result = HJSolver(
            my_car,
            g,
            [goal, obstacle],
            tau,
            compMethods,
            PlotOptions(
                do_plot=True, plot_type="3d_plot", plotDims=[0, 1, 2], slicesCut=[]
            ),
            saveAllTimeSteps=False,
        )

        np.save("reach_avoid_hallway.npy", result)

    # ra()
    brt(dist=True)
    # brt_test(dist=True)

import math
import torch
import numpy as np
class ReachabilitySingleVehicleNarrowPassageSource(Dataset):
    def __init__(
        self,
        numpoints,
        pretrain=False,
        tMin=0.0,
        tMax=0.5,
        counter_start=0,
        counter_end=100e3,
        pretrain_iters=2000,
        norm_scheme="hack1",
        gx_factor=1.0,
        speed_setting="low",
        sampling_bias_ratio=0.0,
        env_setting="v1",
        IC_smoothing_setting="v1",
        HJIVI_smoothing_setting="v1",
        smoothing_exponent=2.0,
    ):
        super().__init__()
        torch.manual_seed(0)

        self.pretrain = pretrain
        self.numpoints = numpoints

        self.num_states = 5

        self.tMax = tMax
        self.tMin = tMin

        # Define state alphas and betas so that all coordinates are from [-1, 1].
        # The conversion rule is state' = (state - beta)/alpha. state' is in [-1, 1].
        # [state sequence: x_Ri, y_Ri, th_Ri, v_Ri, phi_Ri]. Ri is the ith vehicle.
        self.alpha = {}
        self.beta = {}

        if speed_setting == "medium_v2":
            self.alpha["x"] = 8.0
            self.alpha["y"] = 3.8
            self.alpha["th"] = 1.2 * math.pi
            self.alpha["v"] = 4.0
            self.alpha["phi"] = 1.2 * 0.3 * math.pi
            # self.alpha['time'] = 2.0/self.tMax
            self.alpha["time"] = 10.0 / self.tMax

            self.beta["x"] = 0.0
            self.beta["y"] = 0.0
            self.beta["th"] = 0.0
            self.beta["v"] = 3.0
            self.beta["phi"] = 0.0

            # Target positions
            self.goalX = np.array([6.0])
            self.goalY = np.array([-1.4])

            # State bounds
            self.vMin = 0.001
            self.vMax = 6.50
            self.phiMin = -0.3 * math.pi + 0.001
            self.phiMax = 0.3 * math.pi - 0.001

            # Control bounds
            self.aMin = -4.0
            self.aMax = 2.0
            self.psiMin = -3.0 * math.pi
            self.psiMax = 3.0 * math.pi

        else:
            raise NotImplementedError

        # How to weigh the obstacles
        self.gx_factor = gx_factor

        if env_setting == "v2":
            # Vehicle diameter/length
            self.L = 2.0

            # Lower and upper curb positions (in the y direction)
            self.curb_positions = np.array([-2.8, 2.8])

            # Stranded car position
            self.stranded_car_pos = np.array([0.0, -1.8])

            # Stranded car position
            self.stranded_R2_pos = np.array([-6.0, 1.4])

        else:
            raise NotImplementedError

        self.N_src_samples = 1000

        self.pretrain_counter = 0
        self.counter = counter_start
        self.pretrain_iters = pretrain_iters
        self.full_count = counter_end

        self.normalization_scheme = norm_scheme
        self.sampling_bias_ratio = sampling_bias_ratio

        self.clip_value_gradients = False
        self.IC_smoothing_setting = IC_smoothing_setting
        self.HJIVI_smoothing_setting = HJIVI_smoothing_setting
        self.smoothing_exponent = smoothing_exponent

    def compute_lx(self, state_coords_unnormalized):
        # Compute the target boundary condition given the unnormalized state coordinates.
        # Vehicle 1
        goal_tensor_R1 = torch.tensor([self.goalX[0], self.goalY[0]]).type(
            torch.FloatTensor
        )[None]
        dist_R1 = (
            torch.norm(
                state_coords_unnormalized[:, 0:2] - goal_tensor_R1, dim=1, keepdim=True
            )
            - self.L
        )
        return dist_R1

    def compute_gx(self, state_coords_unnormalized):
        # Compute the obstacle boundary condition given the unnormalized state coordinates. Negative inside the obstacle positive outside.
        # Distance from the lower curb
        dist_lc = (
            state_coords_unnormalized[:, 1:2] - self.curb_positions[0] - 0.5 * self.L
        )
        # Distance from the upper curb
        dist_uc = (
            self.curb_positions[1] - state_coords_unnormalized[:, 1:2] - 0.5 * self.L
        )
        # Distance from the stranded car
        stranded_car_pos = torch.tensor(self.stranded_car_pos * 1.0).type(
            torch.FloatTensor
        )
        dist_stranded = (
            torch.norm(
                state_coords_unnormalized[:, 0:2] - stranded_car_pos,
                dim=1,
                keepdim=True,
            )
            - self.L
        )
        # Distance between the vehicles themselves
        stranded_R2_pos = torch.tensor(self.stranded_R2_pos * 1.0).type(
            torch.FloatTensor
        )
        dist_R1R2 = (
            torch.norm(
                state_coords_unnormalized[:, 0:2] - stranded_R2_pos, dim=1, keepdim=True
            )
            - self.L
        )

        if self.IC_smoothing_setting in ["v2"]:
            alpha = self.smoothing_exponent
            soft_min_num = (
                dist_lc * torch.exp(-alpha * dist_lc)
                + dist_uc * torch.exp(-alpha * dist_uc)
                + dist_stranded * torch.exp(-alpha * dist_stranded)
                + dist_R1R2 * torch.exp(-alpha * dist_R1R2)
            )
            soft_min_den = (
                torch.exp(-alpha * dist_lc)
                + torch.exp(-alpha * dist_uc)
                + torch.exp(-alpha * dist_stranded)
                + torch.exp(-alpha * dist_R1R2)
            )
            return (soft_min_num / soft_min_den) * self.gx_factor
        else:
            return (
                torch.min(
                    torch.min(torch.min(dist_lc, dist_uc), dist_stranded), dist_R1R2
                )
                * self.gx_factor
            )

    def compute_IC(self, state_coords):
        # Compute the boundary condition given the normalized state coordinates.
        state_coords_unnormalized = state_coords * 1.0
        state_coords_unnormalized[:, 0] = (
            state_coords_unnormalized[:, 0] * self.alpha["x"] + self.beta["x"]
        )
        state_coords_unnormalized[:, 1] = (
            state_coords_unnormalized[:, 1] * self.alpha["y"] + self.beta["y"]
        )
        state_coords_unnormalized[:, 2] = (
            state_coords_unnormalized[:, 2] * self.alpha["th"] + self.beta["th"]
        )
        state_coords_unnormalized[:, 3] = (
            state_coords_unnormalized[:, 3] * self.alpha["v"] + self.beta["v"]
        )
        state_coords_unnormalized[:, 4] = (
            state_coords_unnormalized[:, 4] * self.alpha["phi"] + self.beta["phi"]
        )

        lx = self.compute_lx(state_coords_unnormalized)
        gx = self.compute_gx(state_coords_unnormalized)
        hx = -gx
        if self.IC_smoothing_setting in ["v2"]:
            alpha = self.smoothing_exponent
            soft_max_num = lx * torch.clamp(
                torch.exp(alpha * lx), max=1e26
            ) + hx * torch.clamp(torch.exp(alpha * hx), max=1e26)
            soft_max_den = torch.clamp(torch.exp(alpha * lx), max=1e26) + torch.clamp(
                torch.exp(alpha * hx), max=1e26
            )
            vx = soft_max_num / soft_max_den
        else:
            vx = torch.max(lx, hx)
        return lx, hx, vx

    def compute_vehicle_ham(self, x, dudx, return_opt_ctrl=False):
        # Limit acceleration bounds based on the speed
        zero_tensor = torch.Tensor([0]).cuda()
        aMin = torch.ones_like(x[..., 3]) * self.aMin
        aMin = torch.where((x[..., 3] <= self.vMin), zero_tensor, aMin)
        aMax = torch.ones_like(x[..., 3]) * self.aMax
        aMax = torch.where((x[..., 3] >= self.vMax), zero_tensor, aMax)

        # Limit steering bounds based on the speed
        psiMin = torch.ones_like(x[..., 4]) * self.psiMin
        psiMin = torch.where((x[..., 4] <= self.phiMin), zero_tensor, psiMin)
        psiMax = torch.ones_like(x[..., 4]) * self.psiMax
        psiMax = torch.where((x[..., 4] >= self.phiMax), zero_tensor, psiMax)

        # Compute optimal control
        opt_acc = torch.where((dudx[..., 3] > 0), aMin, aMax)
        opt_psi = torch.where((dudx[..., 4] > 0), psiMin, psiMax)

        # Compute Hamiltonian
        ham_vehicle = (
            x[..., 3] * torch.cos(x[..., 2]) * dudx[..., 0]
            + x[..., 3] * torch.sin(x[..., 2]) * dudx[..., 1]
            + x[..., 3] * torch.tan(x[..., 4]) * dudx[..., 2] / self.L
            + opt_acc * dudx[..., 3]
            + opt_psi * dudx[..., 4]
        )

        if return_opt_ctrl:
            opt_ctrl = troch.cat((opt_acc, opt_psi), dim=1)
            return ham_vehicle, opt_ctrl
        else:
            return ham_vehicle

    def compute_overall_ham(self, x, dudx, return_components=False):
        alpha = self.alpha
        beta = self.beta

        # Scale the costates appropriately.
        dudx[..., 0] = dudx[..., 0] / alpha["x"]
        dudx[..., 1] = dudx[..., 1] / alpha["y"]
        dudx[..., 2] = dudx[..., 2] / alpha["th"]
        dudx[..., 3] = dudx[..., 3] / alpha["v"]
        dudx[..., 4] = dudx[..., 4] / alpha["phi"]

        # Scale for output normalization
        norm_to = 0.02
        mean = 0.25 * alpha["x"]
        var = 0.5 * alpha["x"]
        dudx = dudx * var / norm_to

        # Scale the states appropriately.
        x_unnormalized = x * 1.0
        x_unnormalized[..., 0] = x_unnormalized[..., 0] * alpha["x"] + beta["x"]
        x_unnormalized[..., 1] = x_unnormalized[..., 1] * alpha["y"] + beta["y"]
        x_unnormalized[..., 2] = x_unnormalized[..., 2] * alpha["th"] + beta["th"]
        x_unnormalized[..., 3] = x_unnormalized[..., 3] * alpha["v"] + beta["v"]
        x_unnormalized[..., 4] = x_unnormalized[..., 4] * alpha["phi"] + beta["phi"]

        # Compute the hamiltonian
        ham_R1 = self.compute_vehicle_ham(x_unnormalized[..., 0:5], dudx[..., 0:5])

        ## Total Hamiltonian (take care of normalization again)
        ham_R1 = ham_R1 / (var / norm_to)
        ham_total = ham_R1

        if return_components:
            return ham_total, ham_R1
        else:
            return ham_total

    def __len__(self):
        return 1

    def __getitem__(self, idx):
        start_time = 0.0  # time to apply  initial conditions

        # uniformly sample domain and include coordinates where source is non-zero
        coords = torch.zeros(self.numpoints, self.num_states).uniform_(-1, 1)

        if self.sampling_bias_ratio > 0.0:
            valid_upper_boundary = (
                self.curb_positions[1] - 0.5 * self.L - self.beta["y"]
            ) / self.alpha["y"]
            num_samples = int(self.numpoints * self.sampling_bias_ratio)
            coords[-num_samples:, 1] = coords[-num_samples:, 1] * valid_upper_boundary

        if self.pretrain:
            # only sample in time around the initial condition
            time = torch.ones(self.numpoints, 1) * start_time
            coords = torch.cat((time, coords), dim=1)
        else:
            # slowly grow time values from start time; this currently assumes t \in [tMin, tMax]
            time = self.tMin + torch.zeros(self.numpoints, 1).uniform_(
                0, (self.tMax - self.tMin) * (self.counter / self.full_count)
            )
            coords = torch.cat((time, coords), dim=1)

            # make sure we always have training samples at the initial time
            coords[-self.N_src_samples :, 0] = start_time

        # Compute the initial value function
        # lx, gx, boundary_values = self.compute_IC(coords[:, 1:])
        lx, hx, boundary_values = self.compute_IC(coords[:, 1:])

        # normalize the value function
        if self.normalization_scheme == "hack1":
            norm_to = 0.02
            mean = 0.25 * self.alpha["x"]
            var = 0.5 * self.alpha["x"]
        else:
            raise NotImplementedError
        # print('Min and max value before normalization are %0.4f and %0.4f' %(min(boundary_values), max(boundary_values)))
        # print('Min and max l(x) before normalization are %0.4f and %0.4f' %(min(lx), max(lx)))
        # print('Min and max g(x) before normalization are %0.4f and %0.4f' %(min(gx), max(gx)))
        # print('Min and max h(x) before normalization are %0.4f and %0.4f' %(min(hx), max(hx)))
        boundary_values = (boundary_values - mean) * norm_to / var
        lx = (lx - mean) * norm_to / var
        # gx = (gx - mean)*norm_to/var
        hx = (hx - mean) * norm_to / var
        # print('Min and max value after normalization are %0.4f and %0.4f' %(min(boundary_values), max(boundary_values)))
        # print('Min and max l(x) after normalization are %0.4f and %0.4f' %(min(lx), max(lx)))
        # print('Min and max g(x) after normalization are %0.4f and %0.4f' %(min(gx), max(gx)))
        # print('Min and max h(x) after normalization are %0.4f and %0.4f' %(min(hx), max(hx)))

        if self.pretrain:
            dirichlet_mask = torch.ones(coords.shape[0], 1) > 0
        else:
            # only enforce initial conditions around start_time
            dirichlet_mask = coords[:, 0, None] == start_time

        if self.pretrain:
            self.pretrain_counter += 1
        elif self.counter < self.full_count:
            self.counter += 1

        if self.pretrain and self.pretrain_counter == self.pretrain_iters:
            self.pretrain = False

        # return {'coords': coords}, {'source_boundary_values': boundary_values, 'dirichlet_mask': dirichlet_mask, 'lx': lx, 'gx': gx}
        return {"coords": coords}, {
            "source_boundary_values": boundary_values,
            "dirichlet_mask": dirichlet_mask,
            "lx": lx,
            "hx": hx,
        }

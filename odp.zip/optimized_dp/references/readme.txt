Resources:
http://heterocl.csl.cornell.edu/doc/tutorials/index.html
https://halide-lang.org/

Reachability toolbox in MATLAB:
https://github.com/HJReachability/helperOC.git
Reachability toolbox in C++: https://github.com/HJReachability/beacls.git

References:
- Chi et al. 2018: Optimization of computations on stencils
- Chen, Tomlin, 2018: Time-dependent reachability computations
- Yang et al. 2013: In-place, time-independent reachability computations

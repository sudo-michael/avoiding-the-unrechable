import numpy as np
import sys

# why?
sys.path.append("atu/optimized_dp")

from Grid.GridProcessing import Grid

# x y th v phi
grid_low = np.array(
    [-8, -3.8, -1.2 * np.pi, 0.001, -0.3 * np.pi + 0.001]
)  # mul by 1.1 to allow mod to go to -pi
grid_high = np.array([8, 3.8, 1.2 * np.pi, 6.5, 0.3 * np.pi - 0.001])

# for v, deepreach normalizes with (v - beta) / alpha to be in range [-1, 1]
# (7 -  3) / 4 -> 1 (-1 -3) / 4 -> -1

# grid_pts = np.array([40, 40, 40, 40, 40])
grid_pts = np.array([20, 20, 20, 20, 20])
grid = Grid(
    grid_low,
    grid_high,
    5,
    grid_pts,
    [2, 4],
)

L = 2.0
CURB_POSITION = np.array([-2.8, 2.8])
STRANDED_CAR_POS = np.array([0.0, -1.8])
STRANDED_R2_POS = np.array([-6.0, 1.4])

GOAL_POS = np.array([6.0, -1.4])

if __name__ in "__main__":
    from Shapes.ShapesFunctions import *
    from dynamics.SingleNarrowPassage import SingleNarrowPassage
    from plot_options import *

    from solver import HJSolver

    # car = SingleNarrowPassage(u_mode="min", d_mode="max") # ra
    car = SingleNarrowPassage(u_mode="max", d_mode="min") # brt

    # using env_setting =='v2'

    goal = CylinderShape(grid, np.array([2, 3, 4]), center=GOAL_POS, radius=L)

    curb = Union(
        Lower_Half_Space(grid, 1, CURB_POSITION[0] + 0.5 * L),
        Upper_Half_Space(grid, 1, CURB_POSITION[1] - 0.5 * L),
    )

    stranded_car = CylinderShape(
        grid, np.array([2, 3, 4]), center=STRANDED_CAR_POS, radius=L
    )
    stranded_r2_pos = CylinderShape(
        grid, np.array([2, 3, 4]), center=STRANDED_R2_POS, radius=L
    )

    # obstacle = Union(curb, Union(stranded_r2_pos, stranded_car))
    obstacle = Union(curb, stranded_car)

    tau = np.arange(start=0, stop = 10 + 0.05, step=0.05)
    # tau = np.arange(start=0, stop=1 + 0.05, step=0.05)

    po = PlotOptions(
        do_plot=True, plot_type="3d_plot", plotDims=[0, 1, 2], slicesCut=[10, 10]
    )

    # comp_method = { "TargetSetMode": "minVWithVTarget", "ObstacleSetMode": "maxVWithObstacle"}
    # result = HJSolver(car, grid, [goal, obstacle], tau, comp_method, po, saveAllTimeSteps=False)
    # # np.save("./atu/envs/assets/brts/single_narrow_passage_ra.npy", result)
    compMethods = {"TargetSetMode": "minVWithV0"}
    result = HJSolver(car, grid, obstacle, tau, compMethods, po, saveAllTimeSteps=False)
    # result = HJSolver(car, grid, goal, tau, compMethods, po, saveAllTimeSteps=False)


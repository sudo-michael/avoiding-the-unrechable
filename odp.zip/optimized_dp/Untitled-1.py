# # %%
# from distutils.log import warn
# import matplotlib.pyplot as plt
# import numpy as np
# import sys
# from Grid.GridProcessing import Grid
# from Shapes.ShapesFunctions import *
# import math
# from dynamics.DubinsCapture import *
# from solver import HJSolver
# from plot_options import *


# # %%
# g = Grid(np.array([-4.0, -4.0, -math.pi]), np.array([4.0, 4.0, math.pi]), 3, np.array([40, 40, 40]), [2])
# # Implicit function is a spherical shape - check out CylinderShape API
# Initial_value_f = CylinderShape(g, [], np.zeros(3), 1)
# lookback_length = 2.0
# t_step = 0.05

# small_number = 1e-5
# tau = np.arange(start=0, stop=lookback_length + small_number, step=t_step)

# # Specify the dynamical object. DubinsCapture() has been declared in dynamics/
# # Control uMode is maximizing, meaning that we're avoiding the initial target set
# my_car = DubinsCapture(uMode="min", dMode="max")

# # Specify how to plot the isosurface of the value function ( for higher-than-3-dimension arrays, which slices, indices
# # we should plot if we plot at all )
# po2 = PlotOptions(do_plot=True, plot_type="3d_plot", plotDims=[0,1,2],
#                   slicesCut=[])


# # %%
# compMethods = { "TargetSetMode": "minVWithV0"}
# # HJSolver(dynamics object, grid, initial value function, time length, system objectives, plotting options)
# # result = HJSolver(my_car, g, Initial_value_f, tau, compMethods, po2, saveAllTimeSteps=True )
# result_final = HJSolver(my_car, g, Initial_value_f, tau, compMethods, po2, saveAllTimeSteps=False)


# # %%
# %matplotlib inline

# # %%
# result.shape
# result_final.shape

# # %%
# np.all(result[..., 0] == result_final)

# # %%
# plt.jet()
# plt.figure(figsize=(13, 8))

# # %%
# import warnings
# warnings.filterwarnings('No contour levels were found within the data range.', module='matplotlib')

# # %%
# X, Y = np.meshgrid(
#     np.linspace(-4, 4, 40),
#     np.linspace(-4, 4, 40)
# )
# cs = plt.contour(X, Y, result_final[:, :, 0], levels=[0])
# # plt.colorbar(cs)
# plt.show()

# # %%
# (result_final < 0).sum()

# # %%


from math import pi
import matplotlib.pyplot as plt
import numpy as np
import time

# generating random data values
x = np.linspace(1, 1000, 5000)
y = np.random.randint(1, 1000, 5000)

# enable interactive mode
plt.ion()

# creating subplot and figure
fig = plt.figure()
ax = fig.add_subplot(111)
(line1,) = ax.plot(x, y)

# setting labels
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.title("Updating plot...")

# looping
for _ in range(50):

    # updating the value of x and y
    line1.set_xdata(x * _)
    line1.set_ydata(y)

    # re-drawing the figure
    fig.canvas.draw()

    # to flush the GUI events
    fig.canvas.flush_events()
    time.sleep(0.1)

import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 6 * np.pi, 100)
y = np.sin(x)

# You probably won't need this if you're embedding things in a tkinter plot...
plt.ion()

fig = plt.figure()
ax = fig.add_subplot(111)
(line1,) = ax.plot(x, y, "r-")  # Returns a tuple of line objects, thus the comma

for phase in np.linspace(0, 10 * np.pi, 500):
    line1.set_ydata(np.sin(x + phase))
    fig.canvas.draw()
    fig.canvas.flush_events()
